"""Two-axis point-to-point timing experiment on the shared GUI transport."""
import csv
import json
import math
import time
from collections import deque
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

from protocol import build_request, build_move_output_relative
from trajectory import decode_axes


def parse_plan(text, cycles, speed):
    points = [tuple(float(v.strip()) for v in line.split(','))
              for line in text.strip().splitlines() if line.strip()]
    if not points or len(points) > 100 or any(len(p) != 2 or not all(math.isfinite(v) for v in p) for p in points):
        raise ValueError('每行填写两个有限角度：电机1角度,电机2角度；最多100行')
    if any(not -29 <= p[0] <= 35 for p in points):
        raise ValueError('电机1目标须在 −29°～+35° 内；仍以板端保护为准')
    if not 1 <= cycles <= 100 or not math.isfinite(speed) or not 0.2 <= speed <= 1.5:
        raise ValueError('循环1～100次；速度设定0.2～1.5，实际输出轴rpm=设定÷6')
    return points * cycles, speed / 6


class JointTimingPanel:
    def __init__(self, app):
        self.app = app
        self.phase = None
        self.rows = []
        self.window = tk.Toplevel(app.root)
        self.window.title('两轴联动往返计时')
        self.window.geometry('1150x650')
        self.window.protocol('WM_DELETE_WINDOW', self.close)
        outer = ttk.Frame(self.window, padding=12); outer.pack(fill='both', expand=True)
        ttk.Label(outer, text='两轴均建立参考后使用。每行一个联动目标（电机1°,电机2°），两轴均停稳后进入下一行。').pack(anchor='w')
        ttk.Label(outer, text='两条定位指令依次发送，不保证同一时刻启动或同步到达；表中记录下发间隔。到位窗口±0.5°，完成容差±0.1°。').pack(anchor='w')
        self.plan = tk.Text(outer, height=4, width=35); self.plan.pack(anchor='w', pady=6)
        self.plan.insert('1.0', '10,10\n0,0\n10,10')
        controls = ttk.Frame(outer); controls.pack(fill='x')
        self.speed = tk.StringVar(value='0.6'); self.cycles = tk.StringVar(value='1')
        for label, variable in (('速度设定（实际rpm=数值÷6）', self.speed), ('循环次数', self.cycles)):
            ttk.Label(controls, text=label).pack(side='left')
            ttk.Entry(controls, textvariable=variable, width=8).pack(side='left', padx=6)
        ttk.Button(controls, text='开始联动计时', command=self.start).pack(side='left', padx=6)
        ttk.Button(controls, text='停止两轴', command=self.stop).pack(side='left', padx=6)
        ttk.Button(controls, text='导出CSV', command=self.export).pack(side='left', padx=6)
        self.status = tk.StringVar(value='尚未开始；不会自动建立或清除参考。')
        ttk.Label(outer, textvariable=self.status, wraplength=1100).pack(anchor='w', pady=10)
        columns = ('step','axis','target','prep','ack','start','window','settle','total','joint_total','skew','result')
        self.table = ttk.Treeview(outer, columns=columns, show='headings', height=16)
        for key, label in zip(columns, ('段','轴','目标°','准备s','应答s','启动s','到位s','到位→停稳s','轴总耗时s','联动总耗时s','下发间隔s','结果')):
            self.table.heading(key, text=label); self.table.column(key, width=94)
        self.table.pack(fill='both', expand=True)

    def start(self):
        if self.phase: return
        try: points, speed = parse_plan(self.plan.get('1.0','end'), int(self.cycles.get()), float(self.speed.get()))
        except ValueError as exc:
            messagebox.showerror('计时参数', str(exc), parent=self.window); return
        a = self.app
        debug = getattr(a,'debug_panel',None)
        if debug and (debug.jobs or debug.after_stop is not None or debug.goto_target is not None or debug.raised_request is not None):
            messagebox.showwarning('流程未完成','请先完成或停止复位/定位流程',parent=self.window); return
        if not a.business_panel.available(): return
        if not messagebox.askyesno('开始两轴联动', f'执行{len(points)}段，两轴实际输出轴速度{speed:g}rpm。\n请确认两轴已有参考，且整段路径可运动。', parent=self.window): return
        self.points = deque(points); self.speed_rpm = speed
        self.rows = []; self.table.delete(*self.table.get_children())
        self.step = 0; self.run_started = time.monotonic(); self.next_read = 0
        self.phase = 'preflight'; self.deadline = self.run_started + 10
        self.jobs = deque(); self.segment = None; self.awaiting = None
        a.motion_generation = getattr(a,'motion_generation',0) + 1
        a.monitor_until = 0; a._lock_auto_axis(True)
        self.status.set('读取两轴新鲜反馈，检查参考与停稳状态…')

    def service(self):
        if not self.phase: return
        a = self.app
        if not a.port: self.disconnected(); return
        if time.monotonic() > self.deadline:
            if self.phase == 'stopping': self.disconnected('停止确认超时，状态未知，请检查两轴'); return
            self.stop('计时超时，已取消后续段'); return
        if a.pending or a.deferred_send: return
        if self.jobs:
            frame = self.jobs.popleft()
            if frame[4] == 0x19:
                axis = frame[3]; self.segment['axes'][axis]['sent'] = time.monotonic()
                a._timing.begin(axis, 'gui_joint_timing', self.segment['target'][axis-1])
            self.awaiting = (frame[3],frame[4])
            if not a._send(frame, frame[4], '两轴联动计时', timing_step=True):self.stop('发送失败')
        elif time.monotonic() >= self.next_read:
            self.next_read = time.monotonic() + .05
            self.awaiting = (1,0x37)
            if not a._send(build_request(1,0x37,parameter=0x4652),0x37,'联动计时：两轴直接反馈',timing_step=True):self.stop('发送失败')

    def handle(self, packet):
        if not self.phase: return False
        if (packet.device_id,packet.command) != self.awaiting: return False
        self.awaiting = None
        if not packet.ok:
            self.stop('命令失败：' + packet.status_text); return True
        now = time.monotonic()
        if packet.command == 0x19:
            if self.phase != 'stopping':self.segment['axes'][packet.device_id]['ack'] = now
            return True
        if packet.command == 6: return True
        if packet.command != 0x37: return False
        try: positions = decode_axes(packet.data)
        except ValueError as exc: self.stop(str(exc)); return True
        if self.phase == 'stopping':
            if self.jobs: return True
            stopped = all(p.source==0 and p.sample_age_ms<=200 and p.motor_rpm==0 and not p.flags&0x30 for p in positions)
            self.zeros = self.zeros + 1 if stopped else 0
            if self.zeros >= 2:
                for axis in (1,2):self.app._timing.stop_confirmed(axis)
                self.phase = None
                for axis in (1,2):self.app._release_stopped_axis(axis)
                self.status.set(self.stop_reason+'；两轴已确认停稳')
            return True
        if any(not p.usable or p.source!=0 or p.sample_age_ms>200 or p.alarm_code or p.guard_fault for p in positions):
            self.stop('参考/直接反馈失效或存在故障'); return True
        if self.phase == 'preflight':
            if any(p.motor_rpm or p.flags&0x30 for p in positions):
                self.stop('开始前两轴未停稳'); return True
            self.begin_segment(positions); return True
        for axis, p in enumerate(positions,1):
            m = self.segment['axes'][axis]
            if 'sent' not in m or 'done' in m: continue
            if p.motor_rpm: m.setdefault('motion',now)
            error = abs(p.angle_deg-self.segment['target'][axis-1])
            if error <= .5: m.setdefault('window',now)
            # Completion uses firmware's independent two-zero confirmation, never a bare zero-speed read.
            if error <= .1 and p.flags&0x40 and not p.flags&0x30 and p.motor_rpm==0:
                m['done'] = now
        if all('done' in m for m in self.segment['axes'].values()):
            self.record_segment('完成')
            self.begin_segment(positions)
        return True

    def begin_segment(self, positions):
        if not self.points:
            self.phase = None
            for axis in (1,2):self.app._release_stopped_axis(axis)
            self.status.set(f'全部完成：{self.step}段，总耗时{time.monotonic()-self.run_started:.3f}s（含初始检查与段间反馈）'); return
        self.step += 1; target = self.points.popleft(); now = time.monotonic()
        self.segment = dict(target=target, began=now, axes={1:{},2:{}})
        self.phase = 'running'
        self.deadline = now + max(abs(t-p.angle_deg) for t,p in zip(target,positions))/(6*self.speed_rpm) + 20
        for axis,p in enumerate(positions,1):
            delta = round(target[axis-1]-p.angle_deg,3)
            if abs(delta) <= .001:
                self.segment['axes'][axis] = dict(done=now, no_motion=True)
            else: self.jobs.append(build_move_output_relative(axis,self.speed_rpm,delta))
        self.status.set(f'第{self.step}段：两轴前往{target}；实际速度{self.speed_rpm:g}rpm')

    def record_segment(self, result):
        s = self.segment
        if s is None: return
        sends = [m['sent'] for m in s['axes'].values() if 'sent' in m]
        skew = round(max(sends)-min(sends),6) if len(sends)==2 else ''
        joint_total = round(max(m['done'] for m in s['axes'].values())-s['began'],6) if all('done' in m for m in s['axes'].values()) else ''
        for axis,m in s['axes'].items():
            sent = m.get('sent')
            def duration(end, start):
                return round(end-start,6) if end is not None and start is not None else ''
            row = dict(step=self.step,axis=axis,target=s['target'][axis-1],
                prep=duration(sent,s['began']),ack=duration(m.get('ack'),sent),
                start=duration(m.get('motion'),sent),window=duration(m.get('window'),sent),
                settle=duration(m.get('done'),m.get('window')),total=duration(m.get('done'),s['began']),
                joint_total=joint_total,skew=skew,result='已在目标，无需运动' if m.get('no_motion') else result)
            self.rows.append(row); self.table.insert('', 'end', values=tuple(row.values()))
            self.app._log('JOINT_TIMING '+json.dumps(row,ensure_ascii=False))
        self.segment = None

    def stop(self, reason='人工停止，后续段已取消'):
        if not self.phase: return
        if self.phase == 'stopping': return
        self.record_segment(reason)
        self.points.clear(); self.jobs = deque([build_request(1,6),build_request(2,6)])
        self.phase = 'stopping'; self.zeros = 0; self.stop_reason = reason
        self.deadline = time.monotonic()+30; self.status.set(reason+'；正在停止两轴…')

    def disconnected(self, reason='连接断开，未完成段状态未知'):
        if not self.phase: return
        self.record_segment(reason)
        # Disconnect cannot wait for responses: best-effort STOP both independent axes.
        if self.app.port:
            for axis in (1,2):
                try: self.app.port.write(build_request(axis,6))
                except Exception: pass
        self.phase = None; self.jobs.clear(); self.points.clear(); self.status.set(reason)

    def export(self):
        path = filedialog.asksaveasfilename(parent=self.window,defaultextension='.csv',filetypes=[('CSV','*.csv')])
        if not path: return
        try:
            with open(path,'w',encoding='utf-8-sig',newline='') as f:
                writer = csv.DictWriter(f,fieldnames=('step','axis','target','prep','ack','start','window','settle','total','joint_total','skew','result'))
                writer.writeheader(); writer.writerows(self.rows)
        except OSError as exc: messagebox.showerror('导出失败',str(exc),parent=self.window)

    def close(self):
        self.stop('关闭窗口，取消后续段'); self.window.withdraw()
